#!/usr/bin/env python3
"""
Encryption & Data-Protection Lab
Run inside a virtualenv:  pip install cryptography argon2-cffi
All data is synthetic. Keys live in memory only (never hardcode real keys).
"""
import os, hashlib, hmac, time
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding, ed25519
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidTag, InvalidSignature
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError


def banner(t):
    print(f"\n{'=' * 64}\n{t}\n{'=' * 64}")


# --------------------------------------------------------------------------
# Exercise 1: Symmetric encryption (AES-256-GCM)
# --------------------------------------------------------------------------
def exercise_symmetric():
    banner("EXERCISE 1: AES-256-GCM (symmetric, authenticated)")
    key = AESGCM.generate_key(bit_length=256)        # CSPRNG-generated key
    aes = AESGCM(key)
    plaintext = b"Patient: Jane Doe | Card: 4111-1111-1111-1111 (synthetic)"
    aad = b"record-id=1001"                          # authenticated, not encrypted
    nonce = os.urandom(12)                           # unique per encryption

    ct = aes.encrypt(nonce, plaintext, aad)
    print("Plaintext :", plaintext.decode())
    print("Key (hex) :", key.hex()[:16] + "... (256-bit)")
    print("Nonce     :", nonce.hex())
    print("Ciphertext:", ct.hex()[:64] + "...")
    print("Decrypted :", aes.decrypt(nonce, ct, aad).decode())

    # Tamper test: flip one bit, GCM must reject it
    bad = bytearray(ct); bad[0] ^= 1
    try:
        aes.decrypt(nonce, bytes(bad), aad)
        print("Tamper test: FAILED (undetected)")
    except InvalidTag:
        print("Tamper test: flipped bit detected -> InvalidTag (integrity OK)")

    # Wrong AAD test
    try:
        aes.decrypt(nonce, ct, b"record-id=9999")
    except InvalidTag:
        print("AAD test   : wrong associated data rejected")

    # Same plaintext, new nonce -> different ciphertext
    ct2 = aes.encrypt(os.urandom(12), plaintext, aad)
    print("Fresh nonce gives different ciphertext:", ct != ct2)


# --------------------------------------------------------------------------
# Exercise 2: Hashing and password protection
# --------------------------------------------------------------------------
def exercise_hashing():
    banner("EXERCISE 2: Hashing and password protection")
    msg = b"Hello, lab!"
    print("SHA-256('Hello, lab!')  :", hashlib.sha256(msg).hexdigest())
    print("SHA-256('Hello, lab?')  :", hashlib.sha256(b"Hello, lab?").hexdigest())
    print("-> one-character change gives a completely different digest (avalanche)")

    # HMAC: integrity + authenticity with a shared secret
    secret = os.urandom(32)
    tag = hmac.new(secret, msg, hashlib.sha256).hexdigest()
    ok = hmac.compare_digest(tag, hmac.new(secret, msg, hashlib.sha256).hexdigest())
    print("HMAC-SHA256 tag         :", tag[:32] + "...", "| verified:", ok)

    password = "C0rrect-Horse-Battery!"
    # BAD: plain SHA-256 is fast and unsalted -> same hash for same password
    print("\n[BAD] unsalted SHA-256  :", hashlib.sha256(password.encode()).hexdigest()[:32] + "...")

    # GOOD: Argon2id (salted, memory-hard)
    ph = PasswordHasher()
    t0 = time.perf_counter(); h1 = ph.hash(password); dt = time.perf_counter() - t0
    h2 = ph.hash(password)
    print("[GOOD] Argon2id hash 1  :", h1)
    print("[GOOD] Argon2id hash 2  :", h2)
    print("Same password, different hashes (random salt):", h1 != h2)
    print(f"Hash time: {dt*1000:.0f} ms (slow on purpose)")
    print("Verify correct password :", ph.verify(h1, password))
    try:
        ph.verify(h1, "wrong-password")
    except VerifyMismatchError:
        print("Verify wrong password   : rejected")

    # scrypt alternative from stdlib
    salt = os.urandom(16)
    d = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    print("scrypt (stdlib) digest  :", d.hex()[:32] + "... salt:", salt.hex())


# --------------------------------------------------------------------------
# Exercise 3: Asymmetric encryption and digital signatures
# --------------------------------------------------------------------------
def exercise_asymmetric():
    banner("EXERCISE 3: RSA-OAEP, RSA-PSS, Ed25519, hybrid encryption")
    priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    pub = priv.public_key()

    # RSA-OAEP encryption (small data only, e.g. a key)
    oaep = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),
                        algorithm=hashes.SHA256(), label=None)
    secret = b"short secret"
    ct = pub.encrypt(secret, oaep)
    print("RSA-3072 OAEP ciphertext:", ct.hex()[:48] + "...", f"({len(ct)} bytes)")
    print("Decrypted with private key:", priv.decrypt(ct, oaep))

    # RSA-PSS signature
    doc = b"Contract v1: pay $100"
    pss = padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                      salt_length=padding.PSS.MAX_LENGTH)
    sig = priv.sign(doc, pss, hashes.SHA256())
    pub.verify(sig, doc, pss, hashes.SHA256())
    print("\nRSA-PSS signature valid on original document")
    try:
        pub.verify(sig, b"Contract v1: pay $900", pss, hashes.SHA256())
    except InvalidSignature:
        print("RSA-PSS: altered document -> signature INVALID (integrity + authenticity)")

    # Ed25519 (ECC) signature
    ed_priv = ed25519.Ed25519PrivateKey.generate()
    ed_pub = ed_priv.public_key()
    s = ed_priv.sign(doc)
    ed_pub.verify(s, doc)
    print(f"\nEd25519 signature ({len(s)} bytes) valid; key is only 32 bytes vs RSA-3072's 384")
    try:
        ed_pub.verify(s, doc + b"!")
    except InvalidSignature:
        print("Ed25519: altered document -> signature INVALID")

    # Hybrid encryption: RSA wraps a random AES key, AES encrypts the bulk data
    big = os.urandom(1_000_000)                     # 1 MB, too big for RSA directly
    session_key = AESGCM.generate_key(256)
    nonce = os.urandom(12)
    data_ct = AESGCM(session_key).encrypt(nonce, big, None)
    wrapped = pub.encrypt(session_key, oaep)
    recovered_key = priv.decrypt(wrapped, oaep)
    out = AESGCM(recovered_key).decrypt(nonce, data_ct, None)
    print("\nHybrid encryption of 1 MB: RSA wrapped the AES key, round-trip OK:", out == big)


# --------------------------------------------------------------------------
# Exercise 4: Common mistakes (security observations)
# --------------------------------------------------------------------------
def exercise_mistakes():
    banner("EXERCISE 4: What NOT to do (observations)")
    key = AESGCM.generate_key(128)
    aes = AESGCM(key)
    nonce = os.urandom(12)
    p1, p2 = b"A" * 16, b"B" * 16
    c1 = aes.encrypt(nonce, p1, None)[:-16]
    c2 = aes.encrypt(nonce, p2, None)[:-16]          # SAME nonce: mistake
    xor_ct = bytes(a ^ b for a, b in zip(c1, c2))
    xor_pt = bytes(a ^ b for a, b in zip(p1, p2))
    print("Nonce reuse leaks plaintext relationships:")
    print("  C1 xor C2 == P1 xor P2 ->", xor_ct == xor_pt)

    weak = {hashlib.sha256(w.encode()).hexdigest(): w
            for w in ["123456", "password", "qwerty", "letmein", "admin"]}
    stolen = hashlib.sha256(b"letmein").hexdigest()
    print("Unsalted SHA-256 cracked by dictionary lookup:", weak.get(stolen))


if __name__ == "__main__":
    exercise_symmetric()
    exercise_hashing()
    exercise_asymmetric()
    exercise_mistakes()
    banner("LAB COMPLETE")
